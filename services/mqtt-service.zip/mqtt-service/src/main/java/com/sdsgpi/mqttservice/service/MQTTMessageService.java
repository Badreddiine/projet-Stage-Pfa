package com.sdsgpi.mqttservice.service;

import com.sdsgpi.mqttservice.entity.MQTTMessage;
import com.sdsgpi.mqttservice.repository.MQTTMessageRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class MQTTMessageService {

    @Autowired
    private MQTTMessageRepository mqttMessageRepository;

    public List<MQTTMessage> findAllMessages() {
        return mqttMessageRepository.findAll();
    }

    public Optional<MQTTMessage> findMessageById(Long id) {
        return mqttMessageRepository.findById(id);
    }

    public MQTTMessage saveMessage(MQTTMessage message) {
        return mqttMessageRepository.save(message);
    }

    public void deleteMessage(Long id) {
        mqttMessageRepository.deleteById(id);
    }
}


